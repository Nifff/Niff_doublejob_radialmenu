Locales['es'] = {
    -- Parte del cliente
    ['switch_job'] = 'Cambiaste trabajo',
    ['timer'] = 'Tienes que esperar %s para cambiar tu trabajo de nuevo',

    -- Parte del server
    ['error_loading'] = 'Hubo un error al cargarte tu job de la database.',
    ['id_offline'] = 'El id que ingresaste no esta en el servidor',
    ['not_fills'] = 'No pusiste todos los campos',
    ['job'] = 'Estas trabajando como %s - %s',
    ['error'] = 'Hubo algunos problemas al cambiar el segundo trabajo, inténtelo de nuevo.',
    ['setjob'] = 'Le pusiste el trabajo a %s',
    ['job_error'] = 'El trabajo no que ingresaste no existe',
    ['no_permissions'] = 'No tienes los permisos suficientes para usar este comando',
}